package com.androidwidgetpoc;

public class ListItem {
    public String ch, heading, content;
}
